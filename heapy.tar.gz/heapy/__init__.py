from .structure_function import StructureFunction
from .time_series import TimeSeries
def ExampleData():
    import os
    import pandas as pd
    ex_data = {}
    df = pd.read_csv(os.path.join(os.path.abspath(os.path.dirname(__file__)),'data/example_lc.csv'))
    ex_data['time'] = df['time'].tolist()
    ex_data['value'] = df['value'].tolist()
    ex_data['error'] = df['error'].tolist()
    del df
    return ex_data
